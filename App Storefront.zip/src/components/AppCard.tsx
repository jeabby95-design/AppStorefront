import { Star, Download } from 'lucide-react';

interface AppCardProps {
  app: {
    id: number;
    name: string;
    developer: string;
    description: string;
    rating: number;
    downloads: string;
    category: string;
    icon: string;
  };
}

export function AppCard({ app }: AppCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm active:bg-gray-50 transition-colors">
      <div className="flex gap-3 p-3">
        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-2xl flex-shrink-0">
          {app.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm truncate">{app.name}</h3>
          <p className="text-gray-600 text-xs truncate mb-1">{app.developer}</p>
          <div className="flex items-center gap-3 mb-2">
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              <span className="text-xs text-gray-600">{app.rating}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <Download className="w-3 h-3" />
              <span className="text-xs">{app.downloads}</span>
            </div>
            <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded">
              {app.category}
            </span>
          </div>
          <p className="text-gray-600 text-xs line-clamp-1 mb-2">{app.description}</p>
        </div>
        <button className="px-4 py-1.5 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors text-xs h-fit mt-1 flex-shrink-0">
          GET
        </button>
      </div>
    </div>
  );
}