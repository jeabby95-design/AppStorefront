interface CategoryChipProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

export function CategoryChip({ label, isSelected, onClick }: CategoryChipProps) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-full whitespace-nowrap transition-colors text-sm ${
        isSelected
          ? 'bg-blue-600 text-white'
          : 'bg-white text-gray-700 active:bg-gray-100'
      }`}
    >
      {label}
    </button>
  );
}