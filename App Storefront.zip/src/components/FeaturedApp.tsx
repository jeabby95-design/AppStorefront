import { Star, Download } from 'lucide-react';

interface FeaturedAppProps {
  app: {
    id: number;
    name: string;
    tagline: string;
    description: string;
    rating: number;
    downloads: string;
    category: string;
    image: string;
  };
}

export function FeaturedApp({ app }: FeaturedAppProps) {
  return (
    <div className="mx-4 relative bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl overflow-hidden shadow-md active:scale-[0.98] transition-transform">
      <div className="p-5">
        <span className="inline-block px-2 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs text-white mb-2">
          {app.category}
        </span>
        <h3 className="text-white mb-1">{app.name}</h3>
        <p className="text-blue-100 text-sm mb-3">{app.tagline}</p>
        
        <img
          src={app.image}
          alt={app.name}
          className="w-full h-40 object-cover rounded-lg shadow-lg mb-3"
        />
        
        <div className="flex items-center gap-4 mb-3 text-white">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm">{app.rating}</span>
          </div>
          <div className="flex items-center gap-1">
            <Download className="w-4 h-4" />
            <span className="text-sm">{app.downloads}</span>
          </div>
        </div>
        
        <button className="w-full py-2.5 bg-white text-blue-600 rounded-lg active:bg-blue-50 transition-colors text-sm">
          Download Now
        </button>
      </div>
    </div>
  );
}