import { useState } from 'react';
import { Search, TrendingUp, Star, Menu, User } from 'lucide-react';
import { AppCard } from './components/AppCard';
import { CategoryChip } from './components/CategoryChip';
import { FeaturedApp } from './components/FeaturedApp';

const categories = [
  'All Apps',
  'Productivity',
  'Games',
  'Social',
  'Entertainment',
  'Education',
  'Health',
  'Business'
];

const featuredApps = [
  {
    id: 1,
    name: 'TaskMaster Pro',
    tagline: 'Master your productivity',
    description: 'The ultimate task management app with AI-powered insights',
    rating: 4.8,
    downloads: '5M+',
    category: 'Productivity',
    image: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=800&q=80'
  }
];

const apps = [
  {
    id: 2,
    name: 'FitLife',
    developer: 'HealthTech Inc.',
    description: 'Track your fitness journey with personalized workouts',
    rating: 4.7,
    downloads: '10M+',
    category: 'Health',
    icon: '🏃'
  },
  {
    id: 3,
    name: 'PhotoVault',
    developer: 'SecureApps',
    description: 'Keep your photos safe with military-grade encryption',
    rating: 4.6,
    downloads: '8M+',
    category: 'Productivity',
    icon: '📸'
  },
  {
    id: 4,
    name: 'MindFlow',
    developer: 'Meditation Co.',
    description: 'Guided meditation and mindfulness exercises',
    rating: 4.9,
    downloads: '15M+',
    category: 'Health',
    icon: '🧘'
  },
  {
    id: 5,
    name: 'CodeLearn',
    developer: 'EduTech',
    description: 'Learn programming with interactive lessons',
    rating: 4.8,
    downloads: '12M+',
    category: 'Education',
    icon: '💻'
  },
  {
    id: 6,
    name: 'BudgetWise',
    developer: 'FinanceTools',
    description: 'Manage your finances and track spending habits',
    rating: 4.5,
    downloads: '6M+',
    category: 'Business',
    icon: '💰'
  },
  {
    id: 7,
    name: 'GameZone Arena',
    developer: 'PlayNow Games',
    description: 'Multiplayer battles with friends worldwide',
    rating: 4.7,
    downloads: '20M+',
    category: 'Games',
    icon: '🎮'
  },
  {
    id: 8,
    name: 'SocialHub',
    developer: 'Connect Inc.',
    description: 'Stay connected with friends and family',
    rating: 4.4,
    downloads: '50M+',
    category: 'Social',
    icon: '💬'
  },
  {
    id: 9,
    name: 'StreamFlix',
    developer: 'Entertainment Plus',
    description: 'Watch unlimited movies and TV shows',
    rating: 4.6,
    downloads: '30M+',
    category: 'Entertainment',
    icon: '🎬'
  },
  {
    id: 10,
    name: 'RecipeBox',
    developer: 'Cooking Made Easy',
    description: 'Thousands of recipes with step-by-step guides',
    rating: 4.7,
    downloads: '9M+',
    category: 'Entertainment',
    icon: '🍳'
  },
  {
    id: 11,
    name: 'LanguageMaster',
    developer: 'Polyglot Apps',
    description: 'Learn any language with AI-powered lessons',
    rating: 4.8,
    downloads: '18M+',
    category: 'Education',
    icon: '🌍'
  },
  {
    id: 12,
    name: 'WeatherPro',
    developer: 'Climate Tech',
    description: 'Accurate weather forecasts and alerts',
    rating: 4.5,
    downloads: '25M+',
    category: 'Productivity',
    icon: '⛅'
  }
];

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState('All Apps');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredApps = apps.filter(app => {
    const matchesCategory = selectedCategory === 'All Apps' || app.category === selectedCategory;
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         app.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 max-w-md mx-auto">
      {/* Mobile Header */}
      <header className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white">📱</span>
              </div>
              <h1>App Store</h1>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <User className="w-5 h-5 text-gray-600" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Menu className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search apps..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>
        </div>
      </header>

      <main className="pb-20">
        {/* Featured Section */}
        {!searchQuery && (
          <section className="mb-6">
            <div className="flex items-center gap-2 px-4 pt-4 pb-3">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <h2>Featured</h2>
            </div>
            {featuredApps.map(app => (
              <FeaturedApp key={app.id} app={app} />
            ))}
          </section>
        )}

        {/* Categories */}
        <section className="mb-6">
          <div className="px-4">
            <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
              {categories.map(category => (
                <CategoryChip
                  key={category}
                  label={category}
                  isSelected={selectedCategory === category}
                  onClick={() => setSelectedCategory(category)}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Apps List */}
        <section className="px-4">
          <div className="flex items-center justify-between mb-3">
            <h2>
              {searchQuery ? 'Search Results' : selectedCategory}
            </h2>
            <span className="text-gray-500 text-sm">
              {filteredApps.length}
            </span>
          </div>
          
          {filteredApps.length > 0 ? (
            <div className="space-y-3">
              {filteredApps.map(app => (
                <AppCard key={app.id} app={app} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-sm">No apps found</p>
            </div>
          )}
        </section>

        {/* Top Rated */}
        {!searchQuery && (
          <section className="mt-8 px-4">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-4 h-4 text-yellow-500" />
              <h2>Top Rated</h2>
            </div>
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              {apps
                .sort((a, b) => b.rating - a.rating)
                .slice(0, 5)
                .map((app, index) => (
                  <div
                    key={app.id}
                    className="flex items-center gap-3 p-3 border-b last:border-b-0 active:bg-gray-50"
                  >
                    <span className="w-6 text-gray-400">{index + 1}</span>
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-xl flex-shrink-0">
                      {app.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="truncate text-sm">{app.name}</h3>
                      <p className="text-gray-600 text-xs truncate">{app.developer}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{app.rating}</span>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t max-w-md mx-auto">
        <div className="flex items-center justify-around py-2">
          <button className="flex flex-col items-center gap-1 px-4 py-2 text-blue-600">
            <div className="w-6 h-6 flex items-center justify-center">
              <span>📱</span>
            </div>
            <span className="text-xs">Apps</span>
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 text-gray-500">
            <div className="w-6 h-6 flex items-center justify-center">
              <span>🎮</span>
            </div>
            <span className="text-xs">Games</span>
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 text-gray-500">
            <div className="w-6 h-6 flex items-center justify-center">
              <span>⭐</span>
            </div>
            <span className="text-xs">Top</span>
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 text-gray-500">
            <div className="w-6 h-6 flex items-center justify-center">
              <span>🔔</span>
            </div>
            <span className="text-xs">Updates</span>
          </button>
        </div>
      </nav>
    </div>
  );
}