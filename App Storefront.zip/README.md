
  # App Storefront

  This is a code bundle for App Storefront. The original project is available at https://www.figma.com/design/1GWcO8wcKWy4NeSM2y2Jva/App-Storefront.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  